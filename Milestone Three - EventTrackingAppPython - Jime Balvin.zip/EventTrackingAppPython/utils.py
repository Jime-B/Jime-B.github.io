from database import add_user, get_user, add_event, get_events, update_event, delete_event
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import calendar

# ===========
# User utils
# ===========

def create_user(username, password):
    existing_user = get_user(username)
    if existing_user:
        return None
    
    hashed_password = generate_password_hash(password)
    user_id = add_user(username, hashed_password)
    return user_id

def validate_user(username, password):
    user = get_user(username)
    if user and check_password_hash(user['password'], password):
        return user
    return None

# ============
# Event utils
# ============

def create_event(user_id, title, event_date):
    add_event(user_id, title, event_date)

def retrieve_events(user_id):
    return get_events(user_id)

def edit_event(event_id, title, event_date):
    update_event(event_id, title, event_date)

def remove_event(event_id):
    delete_event(event_id)

# ================
# Events analytics
# ================

# Convert event_date string to date object
def parse_date(event):
    return datetime.strptime(event['event_date'], "%Y-%m-%d").date()


def get_weekly_event_activity(events):
    week_days = {"Monday":0, "Tuesday":0, "Wednesday":0, "Thursday":0, "Friday":0, "Saturday":0, "Sunday":0}

    # Count events per day
    for event in events:
        parsed_event_date = parse_date(event)
        weekday = parsed_event_date.strftime("%A")
        week_days[weekday] += 1

    counts = list(week_days.values())
    min_count = min(counts)
    max_count = max(counts)

    # Calculate intensity for chart colors and data normalization
    intensity = []

    for count in counts:
        if max_count == min_count:
            intensity.append(0)
        else:
            normalized = (count - min_count) / (max_count - min_count)
            intensity.append(normalized)

    return {
        "labels": list(week_days.keys()),
        "counts": counts,
        "min": min_count,
        "max": max_count,
        "intensity": intensity
    }


def get_monthly_event_activity(events, year, month):
    weekly_count = {1:0, 2:0, 3:0, 4:0, 5:0}

    # Count events per week of the month
    for event in events:
        parsed_event_date = parse_date(event)

        # Check event is in the specified year and month and which week the event belongs to 
        if parsed_event_date.year == year and parsed_event_date.month == month:
            week_of_month = (parsed_event_date.day - 1) // 7 + 1
            week_of_month = min(week_of_month, 5)

            weekly_count[week_of_month] += 1

    counts = list(weekly_count.values())
    max_count = max(counts)
    busiest_week = [week for week, count in weekly_count.items() if count == max_count and max_count > 0]

    return {
        "labels": list(weekly_count.keys()),
        "counts": counts,
        "busiest_week": busiest_week,
        "max": max_count
    }
