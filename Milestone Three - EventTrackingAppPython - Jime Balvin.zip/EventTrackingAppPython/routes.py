from flask import Blueprint, render_template, request, redirect, url_for, session
from utils import create_user, validate_user, create_event, retrieve_events, edit_event, remove_event, get_weekly_event_activity, get_monthly_event_activity
from datetime import datetime

routes = Blueprint('routes', __name__)

# ============================
# Login and Signup / Home page
# ============================
@routes.route('/', methods=['GET', 'POST'])
def login():
    message = ""

    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        action = request.form.get('action')

        # Ensure no empty fields
        if not username or not password:
            message = "Username and password must be entered"
            return render_template('login.html', message=message)

        if action == "login":
            # User validation
            user = validate_user(username, password)            
            if user:
                session['user_id'] = user['user_id']
                session['username'] = user['username']
                return redirect(url_for('routes.dashboard'))
            else:
                message = "Invalid username or password"

        elif action == "signup":
            # Avoid duplicated username
            user_id = create_user(username, password)
            if user_id:
                session['user_id'] = user_id
                session['username'] = username
                session['toast'] = "Account created succesfully!"
                return redirect(url_for('routes.dashboard'))
            else:
                message = "Username already exists"

    return render_template('login.html', message=message)
            

#===========
# Dashboard
# ==========
@routes.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('routes.login'))
    
    username = session['username']
    toast = session.pop('toast', None)
    events = retrieve_events(session['user_id'])

    weekly_activity = get_weekly_event_activity(events)

    # Determine current year and month
    now = datetime.now()
    year = now.year
    month = now.month
    monthly_activity = get_monthly_event_activity(events, year, month)

    return render_template('dashboard.html', username=username, events=events, toast=toast, weekly_activity=weekly_activity, monthly_activity=monthly_activity)        

# =======
# Logout
# =======
@routes.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('routes.login'))

# =======
# Events
# =======

# Add event page
@routes.route('/add_event', methods=['GET'])
def add_event_page_route():
    if 'user_id' not in session:
        return redirect(url_for('routes.login'))
    
    return render_template('add_event.html')


# Add event route
@routes.route('/add_event', methods=['POST'])
def add_event_route():
    title = request.form.get('title')
    event_date = request.form.get('event_date')
    if title and event_date:
        create_event(session['user_id'], title, event_date)
        return redirect(url_for('routes.dashboard'))
    

# Update event page
@routes.route('/event/<int:event_id>')
def event_page_route(event_id):
    if 'user_id' not in session:
        return redirect(url_for('routes.login'))   

    return render_template('event.html', event_id = event_id)
    

# Update event route
@routes.route('/update_event', methods=['POST'])
def update_event_route():
    event_id = request.form.get('event_id')
    title = request.form.get('title')
    event_date = request.form.get('event_date')
    if event_id and title and event_date:
        edit_event(event_id, title, event_date)

    return redirect(url_for('routes.dashboard'))


# Delete event route
@routes.route('/delete_event', methods=['POST'])
def delete_event_route():
    event_id = request.form.get('event_id')
    if event_id:
        remove_event(event_id)

    return redirect(url_for('routes.dashboard'))