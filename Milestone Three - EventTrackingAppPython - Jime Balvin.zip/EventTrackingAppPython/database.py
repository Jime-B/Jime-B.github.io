import sqlite3

DB_path = r"C:\Users\lj4e_\Desktop\EventTrackingAppPython\main.db"

# Database setup
def init_db():
    conn = sqlite3.connect(DB_path)
    cursor = conn.cursor()

    cursor.execute('PRAGMA foreign_keys = ON;')

    # Users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
                   user_id INTEGER PRIMARY KEY AUTOINCREMENT,
                   username TEXT UNIQUE NOT NULL,
                   password TEXT NOT NULL
                   );
     ''')
    
    # Events table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS events (
                   event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                   user_id INTEGER NOT NULL,
                   title TEXT NOT NULL,
                   event_date TEXT NOT NULL,
                   FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
                   );
    ''')

    conn.commit()
    conn.close()


# ==============
# User functions
# ==============
 
def add_user(username, password):
    conn = sqlite3.connect(DB_path)
    cursor = conn.cursor()
    cursor.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, password))
    user_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return user_id

def get_user(username):
    conn = sqlite3.connect(DB_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
    user = cursor.fetchone()
    conn.close()
    return user


# ===============
# Event functions
# ===============

def add_event(user_id, title, event_date):
    conn = sqlite3.connect(DB_path)
    cursor = conn.cursor()
    cursor.execute('INSERT INTO events (user_id, title, event_date) VALUES (?, ?, ?)', (user_id, title, event_date))
    conn.commit()
    conn.close()

def get_events(user_id):
    conn = sqlite3.connect(DB_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM events WHERE user_id = ?', (user_id,))
    events = cursor.fetchall()
    conn.close()
    return events

def update_event(event_id, title, event_date):
    conn = sqlite3.connect(DB_path)
    cursor = conn.cursor()
    cursor.execute('UPDATE events SET title = ?, event_date = ? WHERE event_id = ?', (title, event_date, event_id))
    conn.commit()
    conn.close()

def delete_event(event_id):
    conn = sqlite3.connect(DB_path)
    cursor = conn.cursor()
    cursor.execute('DELETE FROM events WHERE event_id = ?', (event_id,))
    conn.commit()
    conn.close()

    