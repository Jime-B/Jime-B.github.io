from database import add_user, get_user, add_event, get_events, update_event, delete_event
from werkzeug.security import generate_password_hash, check_password_hash

# ===========
# User utils
# ===========

def create_user(username, password):
    existing_user = get_user(username)
    if existing_user:
        return None
    
    hashed_password = generate_password_hash(password)
    user_id = add_user(username, hashed_password)
    return user_id

def validate_user(username, password):
    user = get_user(username)
    if user and check_password_hash(user['password'], password):
        return user
    return None

# ============
# Event utils
# ============

def create_event(user_id, title, event_date):
    add_event(user_id, title, event_date)

def retrieve_events(user_id):
    return get_events(user_id)

def edit_event(event_id, title, event_date):
    update_event(event_id, title, event_date)

def remove_event(event_id):
    delete_event(event_id)